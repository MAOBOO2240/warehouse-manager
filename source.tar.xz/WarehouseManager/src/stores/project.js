import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import { api, ApiError } from '../api'
import { useProductStore } from './products'
import { useStockStore } from './stock'
import { useRemarkStore } from './remarks'
import { useRowOrderStore } from './rowOrder'

export const FILE_LABELS = {
  config: '專案設定 config.json',
  products: '品項清單 products.json',
  locations: '存放地點 locations.json',
  inventory: '即時庫存 inventory.json',
  logs: '歷史紀錄 logs.json',
  remarks: '庫存註記 remarks.json',
  row_order: '庫存清單排列順序 row_order.json',
}

export const useProjectStore = defineStore('project', () => {
  const ready = ref(false)
  const fatal = ref(null) // 無法啟動的錯誤（例如程式放在唯讀資料夾）
  const rootPath = ref('')
  const version = ref('')
  const projects = ref([])
  const current = ref('')
  const loading = ref(false)
  const issues = ref([]) // 開啟專案時偵測到的異常資料檔
  const recovered = ref(false)
  // 專案設定（config.json）；removed_locations 記錄被移除的存放地點與移除時間
  const config = ref({})

  /** 有資料檔異常時進入唯讀，避免以空資料覆蓋掉損壞但可能可救回的檔案 */
  const readOnly = computed(() => issues.value.length > 0)

  function assertWritable() {
    if (readOnly.value) {
      throw new ApiError('READ_ONLY', '資料檔異常，目前為唯讀模式。請先從備份還原後再操作。')
    }
    if (!current.value) throw new ApiError('NO_PROJECT', '尚未開啟專案')
  }

  async function init() {
    try {
      const info = await api.getAppInfo()
      version.value = info.version
      if (info.root_error) {
        fatal.value = info.root_error.message
        return
      }
      rootPath.value = info.root
      projects.value = info.projects
      const target = projects.value.includes(info.last_project) ? info.last_project : projects.value[0]
      if (target) await open(target)
    } catch (err) {
      fatal.value = err.message
    } finally {
      ready.value = true
    }
  }

  async function refreshList() {
    projects.value = await api.getProjects()
  }

  async function open(name) {
    loading.value = true
    try {
      const res = await api.openProject(name)
      current.value = res.name
      issues.value = res.issues
      recovered.value = res.recovered
      config.value = res.data.config ?? {}
      useProductStore().items = res.data.products ?? []
      const stock = useStockStore()
      stock.inventory = res.data.inventory ?? []
      stock.logs = res.data.logs ?? []
      useRemarkStore().items = res.data.remarks ?? []
      useRowOrderStore().items = res.data.row_order ?? []
    } finally {
      loading.value = false
    }
  }

  async function create(name) {
    const created = await api.createProject(name)
    await refreshList()
    await open(created)
    return created
  }

  /** 對每個有備份的異常檔案執行還原，之後重新開啟專案。回傳仍無法還原的檔案。 */
  async function restoreFromBackups() {
    const failed = []
    for (const issue of issues.value) {
      if (!issue.has_backup || issue.code === 'FILE_LOCKED') {
        failed.push(issue.file)
        continue
      }
      try {
        await api.restoreBackup(current.value, issue.file)
      } catch {
        failed.push(issue.file)
      }
    }
    await open(current.value)
    return failed
  }

  /** 刪除專案後開啟剩下的第一個專案，回傳開啟的專案名稱 */
  async function remove(name) {
    const left = await api.deleteProject(name)
    projects.value = left
    await open(left[0])
    return left[0]
  }

  /** 匯入備份 ZIP 成為新專案並切換過去；取消時回傳 null */
  async function importZip() {
    const name = await api.importProjectZip()
    if (!name) return null
    await refreshList()
    await open(name)
    return name
  }

  async function exportZip() {
    return api.exportProjectZip(current.value)
  }

  return {
    ready, fatal, rootPath, version, projects, current, loading, issues, recovered, config, readOnly,
    assertWritable, init, refreshList, open, create, remove, restoreFromBackups, exportZip, importZip,
  }
})
